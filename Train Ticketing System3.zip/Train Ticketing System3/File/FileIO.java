package File;

import javax.swing.*;
import java.io.*;

public class FileIO {

    private static final String FILE_NAME = "bookings.txt";

    public static void save(String[] info) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            for (String data : info) {
                writer.write(data + ", ");
            }
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving booking");
        }
    }

    public static void delete(String name) {
        try {
            File temp = new File("temp.txt");
            BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
            BufferedWriter writer = new BufferedWriter(new FileWriter(temp));

            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {
                if (!line.contains(name)) {
                    writer.write(line + "\n");
                } else {
                    found = true;
                }
            }
            reader.close();
            writer.close();

            new File(FILE_NAME).delete();
            temp.renameTo(new File(FILE_NAME));

            JOptionPane.showMessageDialog(null,
                    found ? "Booking deleted successfully!" : "No booking found.");

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Delete error");
        }
    }

    public static void search(String name) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(name)) {
                    JOptionPane.showMessageDialog(null, "Booking Found:\n" + line);
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "No booking found");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Search error");
        }
    }
}
