package Entity;

import javax.swing.*;
import java.util.*;
import File.FileIO;

abstract class Ticket {
    public abstract void calculateFare();
    public abstract String generateSeat();
}

public class TicketOnlineManager extends Ticket {

    private static final Set<String> seats = new HashSet<>();
    private static final Random rand = new Random();

    public double[] calculateFare(String cls, String type,
                                  int from, int to, int adult, int child) {

        double rate = cls.equals("Standard") ? 55 :
                cls.equals("Economy") ? 85 : 105;

        int stations = Math.abs(to - from);
        if (stations == 0) stations = 1;

        double subtotal = (adult + child * 0.5) * rate * stations;
        if (type.equals("Return")) subtotal *= 2;

        double tax = subtotal * 0.10;
        return new double[]{subtotal, tax, subtotal + tax};
    }

    public String assignSeat() {
        return generateSeat();
    }

    @Override
    public void calculateFare() {}

    @Override
    public String generateSeat() {
        String seat;
        do {
            seat = (char) ('A' + rand.nextInt(6)) + String.valueOf(rand.nextInt(30) + 1);
        } while (seats.contains(seat));
        seats.add(seat);
        return seat;
    }

    public void saveBookingToFile(String[] info) {
        FileIO.save(info);
    }

    public void deleteBookingByName(String name) {
        FileIO.delete(name);
    }

    public void searchBookingByName(String name) {
        FileIO.search(name);
    }
}
