package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import Entity.TicketOnlineManager;

public class OnlineBookingFrame extends JFrame {

    private JTextField txtName, txtPhone, txtEmail, txtSub, txtTax, txtTotal, txtSearch;
    private JTextField[] ticketFields = new JTextField[13];
    private JComboBox<String> cmbFrom, cmbTo;
    private JSpinner spnAdultQty, spnChildQty, spnDate, spnTime;
    private JRadioButton rdbStandard, rdbEconomy, rdbFirstClass;
    private JRadioButton rdbSingle, rdbReturn;
    private ButtonGroup grpClass, grpType;

    private JTable tblTickets;
    private DefaultTableModel ticketTableModel;

    private final TicketOnlineManager tm = new TicketOnlineManager();

    public OnlineBookingFrame() {
        setTitle("Train Ticket Booking System");
        setSize(950, 900);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Add background image
        JLabel background = new JLabel(new ImageIcon("/Users/fuadhasan/IdeaProjects/balck_for_java/trainrrtRRRRRRNOW/image /image.png"));
        background.setBounds(0, 0, 950, 900);
        setContentPane(background);

        addHeader();
        addBookingPanel();
        addTicketPanel();
        addSearchPanel();
        addTicketTable();

        setVisible(true);
    }

    private void addHeader() {
        JLabel title = new JLabel("Train Ticket Booking System");
        title.setBounds(300, 10, 400, 30);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(255, 0, 0, 237));
        add(title);

        // Add train logo
        JLabel logo = new JLabel(new ImageIcon("/Users/fuadhasan/IdeaProjects/balck_for_java/trainrrtRRRRRRNOW/image /rsz_train2_logo.jpg"));
        logo.setBounds(8, 8, 100, 50);
        add(logo);
    }

    private void addBookingPanel() {
        JPanel panel = new JPanel(null);
        panel.setBounds(10, 60, 400, 580);
        panel.setBorder(BorderFactory.createTitledBorder("Booking Panel"));
        panel.setOpaque(false); // Make panel transparent
        add(panel);

        panel.add(new JLabel("Name:")).setBounds(10, 20, 100, 25);
        txtName = new JTextField();
        txtName.setBounds(120, 20, 200, 25);
        panel.add(txtName);

        panel.add(new JLabel("Phone:")).setBounds(10, 50, 100, 25);
        txtPhone = new JTextField();
        txtPhone.setBounds(120, 50, 200, 25);
        panel.add(txtPhone);

        panel.add(new JLabel("Email:")).setBounds(10, 80, 100, 25);
        txtEmail = new JTextField();
        txtEmail.setBounds(120, 80, 200, 25);
        panel.add(txtEmail);

        panel.add(new JLabel("Class:")).setBounds(10, 110, 100, 25);
        rdbStandard = new JRadioButton("Standard");
        rdbEconomy = new JRadioButton("Economy");
        rdbFirstClass = new JRadioButton("First Class");

        rdbStandard.setBounds(10, 135, 100, 25);
        rdbEconomy.setBounds(120, 135, 100, 25);
        rdbFirstClass.setBounds(230, 135, 120, 25);

        panel.add(rdbStandard);
        panel.add(rdbEconomy);
        panel.add(rdbFirstClass);

        grpClass = new ButtonGroup();
        grpClass.add(rdbStandard);
        grpClass.add(rdbEconomy);
        grpClass.add(rdbFirstClass);

        panel.add(new JLabel("Ticket Type:")).setBounds(10, 165, 100, 25);
        rdbSingle = new JRadioButton("Single");
        rdbReturn = new JRadioButton("Return");

        rdbSingle.setBounds(10, 190, 100, 25);
        rdbReturn.setBounds(120, 190, 100, 25);

        panel.add(rdbSingle);
        panel.add(rdbReturn);

        grpType = new ButtonGroup();
        grpType.add(rdbSingle);
        grpType.add(rdbReturn);

        panel.add(new JLabel("Adult Qty:")).setBounds(10, 220, 100, 25);
        spnAdultQty = new JSpinner(new SpinnerNumberModel(1, 0, 10, 1));
        spnAdultQty.setBounds(120, 220, 60, 25);
        panel.add(spnAdultQty);

        panel.add(new JLabel("Child Qty:")).setBounds(10, 250, 100, 25);
        spnChildQty = new JSpinner(new SpinnerNumberModel(0, 0, 10, 1));
        spnChildQty.setBounds(120, 250, 60, 25);
        panel.add(spnChildQty);

        String[] stations = {
                "Dhaka Kamalapur", "Joydevpur", "Tongi",
                "Mirzapur", "Tangail", "Jamuna Shetu",
                "Natore", "Rajshahi"
        };

        panel.add(new JLabel("From:")).setBounds(10, 280, 100, 25);
        cmbFrom = new JComboBox<>(stations);
        cmbFrom.setBounds(120, 280, 200, 25);
        panel.add(cmbFrom);

        panel.add(new JLabel("To:")).setBounds(10, 310, 100, 25);
        cmbTo = new JComboBox<>(stations);
        cmbTo.setBounds(120, 310, 200, 25);
        panel.add(cmbTo);

        panel.add(new JLabel("Date:")).setBounds(10, 340, 100, 25);
        spnDate = new JSpinner(new SpinnerDateModel());
        spnDate.setEditor(new JSpinner.DateEditor(spnDate, "yyyy-MM-dd"));
        spnDate.setBounds(120, 340, 200, 25);
        panel.add(spnDate);

        panel.add(new JLabel("Time:")).setBounds(10, 370, 100, 25);
        spnTime = new JSpinner(new SpinnerDateModel());
        spnTime.setEditor(new JSpinner.DateEditor(spnTime, "HH:mm"));
        spnTime.setBounds(120, 370, 200, 25);
        panel.add(spnTime);

        panel.add(new JLabel("SubTotal:")).setBounds(10, 400, 100, 25);
        txtSub = new JTextField();
        txtSub.setBounds(120, 400, 100, 25);
        txtSub.setEditable(false);
        panel.add(txtSub);

        panel.add(new JLabel("Tax (10%):")).setBounds(10, 430, 100, 25);
        txtTax = new JTextField();
        txtTax.setBounds(120, 430, 100, 25);
        txtTax.setEditable(false);
        panel.add(txtTax);

        panel.add(new JLabel("Total:")).setBounds(10, 460, 100, 25);
        txtTotal = new JTextField();
        txtTotal.setBounds(120, 460, 100, 25);
        txtTotal.setEditable(false);
        panel.add(txtTotal);

        // Buttons
        JButton btnTotal = new JButton("Total");
        JButton btnSave = new JButton("Save");
        JButton btnClear = new JButton("Clear");
        JButton btnDelete = new JButton("Delete");
        JButton btnUpdate = new JButton("Update");

        btnTotal.setBounds(10, 500, 80, 30);
        btnSave.setBounds(100, 500, 80, 30);
        btnClear.setBounds(190, 500, 80, 30);
        btnDelete.setBounds(10, 540, 80, 30);
        btnUpdate.setBounds(100, 540, 80, 30);

        panel.add(btnTotal);
        panel.add(btnSave);
        panel.add(btnClear);
        panel.add(btnDelete);
        panel.add(btnUpdate);

        btnTotal.addActionListener(e -> calculateAndDisplayTicket());
        btnSave.addActionListener(e -> saveBooking());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> deleteBooking());
        btnUpdate.addActionListener(e -> updateBooking());
    }

    private void addTicketPanel() {
        JPanel panel = new JPanel(null);
        panel.setBounds(420, 60, 500, 520);
        panel.setBorder(BorderFactory.createTitledBorder("Ticket Info"));
        panel.setOpaque(false); // Make panel transparent
        add(panel);

        String[] labels = {
                "Name", "Phone", "Email", "Class", "Ticket Type",
                "Adult", "Child", "From", "To",
                "Date", "Time", "Seat No", "Total"
        };

        for (int i = 0; i < labels.length; i++) {
            panel.add(new JLabel(labels[i])).setBounds(10, 25 + i * 35, 100, 25);
            ticketFields[i] = new JTextField();
            ticketFields[i].setBounds(120, 25 + i * 35, 350, 25);
            ticketFields[i].setEditable(false);
            panel.add(ticketFields[i]);
        }
    }

    private void calculateAndDisplayTicket() {
        if (txtName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all details");
            return;
        }

        String ticketClass =
                rdbStandard.isSelected() ? "Standard" :
                        rdbEconomy.isSelected() ? "Economy" : "First Class";

        String ticketType = rdbSingle.isSelected() ? "Single" : "Return";

        int adult = (int) spnAdultQty.getValue();
        int child = (int) spnChildQty.getValue();

        double[] res = tm.calculateFare(
                ticketClass, ticketType,
                cmbFrom.getSelectedIndex(),
                cmbTo.getSelectedIndex(),
                adult, child
        );

        txtSub.setText(String.format("%.2f", res[0]));
        txtTax.setText(String.format("%.2f", res[1]));
        txtTotal.setText(String.format("%.2f", res[2]));

        String seat = tm.assignSeat();

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");

        String[] info = {
                txtName.getText(), txtPhone.getText(), txtEmail.getText(),
                ticketClass, ticketType,
                String.valueOf(adult), String.valueOf(child),
                cmbFrom.getSelectedItem().toString(),
                cmbTo.getSelectedItem().toString(),
                df.format(spnDate.getValue()),
                tf.format(spnTime.getValue()),
                seat, "Tk " + txtTotal.getText()
        };

        // Display the calculated ticket details in the Ticket Info panel
        for (int i = 0; i < info.length; i++) {
            ticketFields[i].setText(info[i]);
        }
    }

    private void saveBooking() {
        calculateAndDisplayTicket();

        String[] info = new String[ticketFields.length];
        for (int i = 0; i < ticketFields.length; i++) {
            info[i] = ticketFields[i].getText();
        }

        tm.saveBookingToFile(info);
        ticketTableModel.addRow(info);

        JOptionPane.showMessageDialog(this, "Ticket Booked Successfully!");
    }

    private void clearForm() {
        txtName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtSub.setText("");
        txtTax.setText("");
        txtTotal.setText("");
        grpClass.clearSelection();
        grpType.clearSelection();
        spnAdultQty.setValue(1);
        spnChildQty.setValue(0);
        cmbFrom.setSelectedIndex(0);
        cmbTo.setSelectedIndex(0);
        spnDate.setValue(new java.util.Date());
        spnTime.setValue(new java.util.Date());
        for (JTextField field : ticketFields) {
            field.setText("");
        }
    }

    private void deleteBooking() {
        int row = tblTickets.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a row to delete");
            return;
        }
        ticketTableModel.removeRow(row);
        JOptionPane.showMessageDialog(this, "Booking Deleted Successfully");
    }

    private void updateBooking() {
        int row = tblTickets.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a row to update");
            return;
        }

        calculateAndDisplayTicket();

        for (int i = 0; i < ticketFields.length; i++) {
            ticketTableModel.setValueAt(ticketFields[i].getText(), row, i);
        }

        JOptionPane.showMessageDialog(this, "Booking Updated Successfully");
    }

    private void addSearchPanel() {
        JPanel panel = new JPanel(null);
        panel.setBounds(10, 620, 400, 90);
        panel.setBorder(BorderFactory.createTitledBorder("Search Booking"));
        panel.setOpaque(false); // Make panel transparent
        add(panel);

        panel.add(new JLabel("Search by Name:")).setBounds(10, 25, 150, 25);
        txtSearch = new JTextField();
        txtSearch.setBounds(160, 25, 200, 25);
        panel.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(160, 55, 80, 25);
        panel.add(btnSearch);

        JButton btnReset = new JButton("Reset");
        btnReset.setBounds(250, 55, 80, 25);
        panel.add(btnReset);

        btnSearch.addActionListener(e -> searchBooking());
        btnReset.addActionListener(e -> clearForm());
    }

    private void addTicketTable() {
        String[] cols = {
                "Name", "Phone", "Email", "Class", "Type",
                "Adult", "Child", "From", "To",
                "Date", "Time", "Seat", "Total"
        };

        ticketTableModel = new DefaultTableModel(cols, 0);
        tblTickets = new JTable(ticketTableModel);
        tblTickets.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane sp = new JScrollPane(tblTickets);
        sp.setBounds(10, 720, 920, 140);
        add(sp);
    }

    private void searchBooking() {
        String searchName = txtSearch.getText().trim();
        if (searchName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a name to search.");
            return;
        }

        boolean found = false;
        for (int i = 0; i < ticketTableModel.getRowCount(); i++) {
            String name = ticketTableModel.getValueAt(i, 0).toString();
            if (name.equalsIgnoreCase(searchName)) {
                for (int j = 0; j < ticketFields.length; j++) {
                    ticketFields[j].setText(ticketTableModel.getValueAt(i, j).toString());
                }
                tblTickets.setRowSelectionInterval(i, i);
                found = true;
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "No booking found for the name: " + searchName);
        }
    }
}